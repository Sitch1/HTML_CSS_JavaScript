const searchButton = document.getElementById("searchButton");
const searchInput = document.getElementById("searchInput");
const answerField = document.getElementById("answer");
const list = document.getElementById("list");
const submitButton = document.getElementById("submitButton");
const methodSelect = document.getElementById("method");
const deleteId = document.getElementById("deleteId");
const deleteButton = document.getElementById("deleteButton")

submitButton.addEventListener("click", () => {
    if (methodSelect.value == "create") {
        createMovie()
    }
})

methodSelect.addEventListener("change", () => {
    if (methodSelect.value == "create") {
        idInput.style.display = "none";
    }
})

deleteButton.addEventListener("Click", () => {
    deleteMovie()
})

searchButton.addEventListener("click", () => {
    const inputValue = searchInput.value;

    if (inputValue) {
        fetch("http://localhost:5005/movie/search?Title=" + inputValue)
            .then(res => res.json())
            .then(data => {
                let movieInfo = "ID: " + data.Id + "\n" + data.Title + "\n" + data.Year
                console.log(data);
                answerField.innerText = movieInfo;
                refreshList()
            })
            .catch(err => {
                console.error("Fehler beim auslesen!", err);
            })

    } else { console.log("Kein Inhalt!") }
})

function createMovie() {
    try {
        const requestBody = {
            Title: createInputTitle.value,
            Year: createInputYear.value
        }
        fetch("http://localhost:5005/movie", {
            method: "Post",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(requestBody)
        }).then(res => res.json())
            .then(data => {
                answerField.innerText = JSON.stringify(data);
                refreshList()
            })
            .catch(err => {
                console.error("Mistake POST", err);
            })
    } catch (err) {
        console.log("Mistake fetch: " + err)
    }
}

function deleteMovie() {
    fetch(`http://localhost:5005/movie/${deleteId.value}`, {
        method: "DELETE"
    })
        .then(res => res.json())
        .then(data => {
            answerField.innerText = JSON.stringify(data)
            refreshList()
        })
}

function refreshList() {
    list.innerHTML = "";
    fetch("http://localhost:5005/movie")
        .then(res => res.jason())
        .then(data => {
            data.forEach(element => {
                let newListItem = document.createElement("li");
                newListItem.innerHTML = `#${element.id}:${element.Title}(${element.Year})`
                list.appendChild(newListItem)
            });
        })
        .catch(err => {
            console.error("fehler beim refresh!")
        })
}